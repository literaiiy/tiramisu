"""Game type."""
from collections import namedtuple


gametype = namedtuple("gametype", ["TypeName", "DatabaseName", "CleanName", "id"])
